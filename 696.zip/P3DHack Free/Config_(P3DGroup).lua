dofile(ModPath .."Free_P3DHack_New/Hooks/Tools/ConfigTools.luac") -- DO NOT REMOVE OR EDIT

--[[
-- Настройки лазера --
-- Список доступных цветов
AliceBlue, AntiqueWhite, Aqua, Aquamarine, Azure, Beige, Bisque, BlanchedAlmond, BlueViolet, Brown, BurlyWood, CadetBlue,
Chartreuse, Chocolate, Coral, CornflowerBlue, Cornsilk, Crimson, Cyan, DarkBlue, DarkCyan, DarkGoldenRod, DarkGray,
DarkGreen, DarkKhaki, DarkMagenta, DarkOliveGreen, DarkOrange, DarkOrchid, DarkRed, DarkSalmon, DarkSeaGreen, DarkSlateBlue,
DarkSlateGray, DarkTurquoise, DarkViolet, DeepPink, DeepSkyBlue, DimGray, DodgerBlue, FireBrick, ForestGreen, Fuchsia, Gainsboro,
Gold, GoldenRod, Gray, GreenYellow, HoneyDew, HotPink, IndianRed, Indigo, Khaki, Lavender, LavenderBlush, LawnGreen, LemonChiffon, LightBlue,
LightCoral, LightCyan, LightGoldenRodYellow, LightGray, LightGreen, LightPink, LightSalmon, LightSeaGreen, LightSkyBlue, LightSlateGray,
LightSteelBlue, LightYellow, Lime, LimeGreen, Linen, Magenta, Maroon, MediumAquaMarine, MediumBlue, MediumOrchid, MediumPurple, MediumSeaGreen,
MediumSlateBlue, MediumSpringGreen, MediumTurquoise, MediumVioletRed, MidnightBlue, MintCream, MistyRose, Moccasin, Navy, OldLace,
Olive, OliveDrab, Orange, OrangeRed, Orchid, PaleGoldenRod, PaleGreen, PaleTurquoise, PaleVioletRed, PapayaWhip, PeachPuff, Peru, Pink, Plum,
PowderBlue, RosyBrown, RoyalBlue, SaddleBrown, Salmon, SandyBrown, SeaGreen, SeaShell, Sienna, Silver, SkyBlue, SlateBlue,
SlateGray, SpringGreen, SteelBlue, Tan, Teal, Thistle, Tomato, Turquoise, Violet, Wheat, YellowGreen
----------------------------------------------------------------------------------------------------
]]
--------------------------------------------------------------------------------------------------------------------------------------------------------------------
--[[ 
-- P3DHack CONFIG --
Ниже можно все отредактировать под себя
true = Включить, false = Выключить
]]
P3DGroup_P3DHack = {
	----------------------
	---- Контур меню -----
	----------------------
	Title_Menu_Color = Color.LightGray, -- Цвет контура верхнего меню
	Main_Menu_Color = Color.LightGray, -- Цвет контура основного меню
	Navigation_Menu_Color = Color.LightGray, -- Цвет контура нижнего меню
	---------------------------------------------------------------------
	------------------
	-- Основное --
	------------------
	-- Автоматический выбор случайной карты -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Auto_Pick_Card = false, --Выбирает случайную карту в конце ограбления

	-- Нет паузы -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Dropin_Pause_Remove = true, -- Удаляет паузу, когда игрок подключается к игре

	-- Бесплатные покупки -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Favors = true, --Бесконечные очки планирования
	Free_Assets = true, -- Бесплатные покупки активов
	Free_Casino = true, -- Бесплатные покупки в казино
	Free_Contracts = true, -- Бесплатные покупки контрактов
	Free_Masks = true, -- Бесплатная покупка масок
	Free_PrePlanning = true, -- Бесплатные предварительно запланированные активы
	Free_Skills = true, -- Бесплатная покупка навыков
	Free_Slots = true, -- Бесплатные слоты оружия/масок
	Free_Weapons = true, -- Бесплатное оружие
	Free_Weapon_Mods = true, -- Бесплатные покупки оружейных модификаций

	-- Здоровье -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	No_Job_Heat = true, -- Отключите, если не хотите получить бонус к здоровью
	Job_Heat_Amount = 1.20, -- Настройте бонус к здоровью (По умолчанию 1.15 = 15%)

	-- Авто-плита -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Rats_Message = true, -- Показывает, что нужно в данный момент положить

	-- Не ждать подсчета опыта после окончания ограбления -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Skip_End_Screen = true, -- Не ждать подсчета опыта после окончания ограбления

	-- Стреляете сквозь... -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Bullet_Penetration = true, -- Работает на все оружия, кроме ружий (Выберите ниже)
	Bullet_Penetration_Enemy = true, -- Стреляете через врагов
	Bullet_Penetration_Shield = true, -- Стреляете сквозь щиты
	Bullet_Penetration_Wall = true, -- Стреляете сквозь стены
	
	-- Оружие/Маски -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	MaxMaskRows = 100, -- Слоты для масок
	MaxWeaponRows = 100, -- Слоты для оружий

	-- Зиплайн -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Zipline_Drop = true, -- Можете бросать сумки, когда вы на Zip-line----------------
	----------------------------
	-- Привязка клавиш/Нумпад --
	----------------------------
	-- Включить автоматически
	Keyboard_Auto_Config = true, -- Автоматический бинд клавиш (Клавиши смотреть ниже)
	X_Ray = false, -- Отмечает всех в игре; По умолчанию на 'X'

	-- Включение/Выключение клавиш здесь. Настройте то, что хотите включить или выключить.
	-- Пополнение здоровья и патронов(Z) --
	Full_Replenish = true, -- Пополняет здоровье и патроны

	-- Пополняет патроны (C) --
	Ammo_Replenish = true, -- Пополняет патроны

	-- Спавн гранат (B) --
	Grenade_Spawn = true, -- Спавн гранат
	Grenade_Spawn_Type = 'Random_Projectile', -- Выберете тип гранаты ("Random_Projectile", "frag", "launcher_frag", "rocket_frag", "molotov", "launcher_incendiary", "launcher_frag_m32", "wpn_prj_four", "wpn_prj_ace", "wpn_prj_jav")

	-- Включение/Выключение Худа (F10) --
	Hud_Toggle = true, -- Включает/выключает Худ в игре

	-- Перезапуск игры (NUMPAD /) --
	Restart_Job = true, -- Перезапуск игры (Только хост)

	-- Спавн Гейдж пакетов (\) --
	Gage_Package = true, -- Спавнить Гейдж пакеты на прицел

	-- Убить всех (NUMPAD *) --
	Ultimate_Kill = true, -- Убивает абсолютно всех

	-- Заспавнить машину (Управляемую) (V)--
	Vehicle_Spawn = true, -- Спавн машинына V (Только Автосалон)

	-----------------
	-- Перед игрой --
	-----------------
	-- Включается автоматически -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Auto_Cheats = true, -- Все нижеперечисленное будет работать если стоит true
	Bag_CoolDown = false, -- У сумок нет кулдауна
	Camera_Bag_Explosion_Multiplier = false, -- Множитель взрыва
	Camera_Bag_Explosion_Multiplier_Amount = 0, -- (По умолчанию 4)
	Dodge_Chance_Buff = false, -- Шанс уклонения
	Dodge_Chance_Buff_Amount = 0.5, -- Шанс уклонения (0.1 = 10%, 1 = 100%)
	Dynamite_Buff = false,  -- Усиление динамита
	Dynamite_Damage_Buff = 1000, -- Усиление урона для динамита (По умолчанию 30)
	Dynamite_Self_Damage = 0, -- Урон наносимый персонажу от динамита (По умолчанию 10)
	Dynamite_Range_Buff = 2000, -- Дистанция броска динамитной шашки (По умолчанию 1000)
	Explosion_Buff = false, -- Включить ниже перечисленные усиления
	Explosion_Buff_Amount = 500, -- Все взрывы получают дополнительный урон
	Fast_Mask = false, -- Быстрая маска
	GL40_Buff = false, -- GL40 Увеличение урона
	GL40_Buff_Damage_Amount = 2000, -- GL40 прибавка к урону (По умолчанию 34)
	GL40_Buff_Player_Damage_Amount = 0, -- GL40 урон наносимый игроку (По умолчанию 8)
	GL40_Buff_Range_Amount = 2000, -- GL40 Дальность запуска гранат(По умолчанию 350)
	GL40_Buff_Time_Amount = 5, -- GL40 Задержка взрыва (По умолчанию 2.5)
	Grenade_Buff = false, -- Усиление гранат
	Grenade_Buff_Damage_Amount = 300, -- Урон от гранаты (По умолчанию 30)
	Grenade_Buff_Player_Damage_Amount = 10, -- урон себе (По умолчанию 10)
	Grenade_Buff_Range_Amount = 1200, -- Дальность гранаты (По умолчанию 1000)
	Incendiary_Grenade_Buff = false, -- Усиление молотова
	Incendiary_Grenade_Buff_Damage_Amount = 2000, -- Урон от молотова врагам(По умолчанию 3)
	Incendiary_Grenade_Buff_Player_Damage_Amount = 0, -- Урон от молотова себе (По умолчанию 2)
	Incediary_Grenade_Buff_Range_Amount = 2000, -- Дальность броска молотова (По умолчанию 75)
	Incendiary_Grenade_Buff_Burn_Duration_Amount = 5, -- Продолжительность (По умолчанию 6)
	Incendiary_Grenade_Buff_Time_Amount = 2.5, -- Задержка взрыва (По умолчанию 2.5)
	Infinite_Hostage_Follow = false, -- Бесконечный захват заложников
	Infinite_Stamina = false, -- Бесконечная выносливость
	Interaction_CoolDown = false, -- Мгновенное взаимодействие
	Jump_Mask_Off = true, -- Прыгать, когда маска выключена
	Lowered_Headbob = false, -- Опущена голова у фигурки бульдозера
	Melee_Buff = false, -- Усиление рукопашной атаки
	Melee_Buff_Amount = 1000, -- Урон с рукопашной атаки, врежь ему хорошенько!!!
	Molotov_Buff = false, -- Усиление молотова
	Molotov_Buff_Damage_Amount = 2000, -- Урон от молотова врагам (По умолчанию 3)
	Molotov_Buff_Player_Damage_Amount = 0, -- Урон от молотова себе(По умолчанию 2)
	Molotov_Buff_Range_Amount = 10000, -- Дальность броска молотова (По умолчанию 75)
	Molotov_Buff_Burn_Duration_Amount = 30, -- Сколько площади горит(По умолчанию 20)
	No_FlashBang = false, -- Нет ослепления
	No_Recoil = false, -- Без отдачи
	No_Spread = false, -- 100% точность (Исключение дробовики)
	RPG7_Buff = false, -- RPG-7 усиление
	RPG7_Buff_Damage_Amount = 2000, -- RPG-7 урон (По умолчанию 1000)
	RPG7_Buff_Player_Damage_Amount = 0, -- RPG-7 урон игроку (По умолчанию 40)
	RPG7_Buff_Range_Amount = 2000, -- RPG-7 Диапазон взрыва(По умолчанию 500)
	RPG7_Buff_Time_Amount = 5, -- RPG-7 задержка перед взрывом (По умолчанию 2.5)
	Sixth_Sense_Reset = false, -- 6 чувство
	Unlimited_BodyBags = false, -- Бесконечные мешки для трупов

	-- Множитель опыта -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	XP_Multiplier = false, -- Включить множитель урона
	XP_Multiplier_Amount = 2, -- Множитель опыта

	-- Случайный лут -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Auto_Loot = false, -- Спавнить случайный лут (Только хост)
	Auto_Equipment = false, -- Спавн оборудования

	-- Мешки для трупов -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Secure_BodyBags = false, -- Мешки для трупов (Только хост)
	Secure_BodyBags_Loot_Value = 1000, -- Цена за сумку

	-- Взаимодействие -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Toggle_Interact = true, -- Переключить взаимодействие нижних функций

	-- Другие настройки -- (Требуется перезагрузка игры, что бы вступило в силу вступили в силу)
	Grenade_Restrict = false, -- Отключение гранат во время стелса
	Pager_Mod = false, -- Увеличение количества пейджеров (Только хост)
	Upgrade_Tweaks = false, -- Дополнительные настройки (Редактировать в '/Head/UpgradeTweakConfig') (Только хост)
	--------------------------------------------------------------------------------------------------------------------
	----------------
	-- Игрок (F1) --
	----------------
	-- Опции --
	Player_Menu_Config = false, -- Игрок(F1)
	------------------------------
	-- Оружейное меню (F2) --
	------------------------------
	Weapon_Menu_Config = false, -- Оружейное меню
	Sentry_Infinite_Ammo = false, -- Турель стреляет без перезарядки и имеет бесконечные патроны
	Weapon_Damage_Multiplier = false, -- Множитель урона для оружия
	Weapon_Damage_Multiplier_Amount = 500, -- Множитель урона (Должно быть включено в игре)
	Weapon_Fire_Rate_Multiplier = false, -- Скорострельность для оружия
	Weapon_Fire_Rate_Multiplier_Amount = 5000, -- Множитель скорострельности (Должно быть включено в игре)
	Weapon_Reload_Speed_Multiplier = false, -- Множитель перезарядки
	Weapon_Reload_Speed_Multiplier_Amount = 10, -- Множитель скорости перезарядки (Должно быть включено в игре)
	Weapon_Swap_Speed_Multiplier = false, -- Быстрая смена оружия
	Weapon_Swap_Speed_Multiplier_Amount = 1.8, -- Множитель скорости (Должно быть включено в игре)
	-----------------------
	-- Стелс меню (F3) --
	-----------------------
	Stealth_Menu_Config = false, -- Стелс меню (F3)
	----------------------------------------------
	-- Настройки Манипулятор миссии (F4) --
	----------------------------------------------
	Mission_Manipulator_config = false, -- Манипулятор миссий (F4) (Не влияет на анти-чит)
	-- Анти-чит отключен --
	Anti_Cheat_Disable = true, -- Отключить Анти-чит
	-- Открыть все двери
	Classic_Open_Door = true, -- Желаете открыть все двери, сейвы... Все, кроме комнаты охраны
	New_Open_Door = true, -- Желаете открыть все двери, сейфы... Все, кроме комнаты охраны
}