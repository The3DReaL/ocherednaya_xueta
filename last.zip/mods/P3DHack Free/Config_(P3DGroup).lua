﻿------------------------------------------------------
-- OPEN ONLY IN NOTEPAD++ OR OTHERS CUSTOM NOTEPADS --
------------------------------------------------------
--[[
	--------------------
	-- P3DHack Config --
	--------------------
	Here you can change everything for yourself
	true = on, false = off
]]
P3DGroup_P3DHack = {
	--------------------
	-- Main functions --
	--------------------
	No_FlashBang = false, -- No FlashBangs
	No_Recoil = false, -- No weapon recoil
	No_Spread = false, -- No weapon spread (Excludes Shotguns)
	Infinite_Stamina = false, -- Infinite stamina
	--------------------
	-- Free purchases --
	--------------------
	free_purchase = true, -- Do you want enable free purchases?
		Favors = true, --Free preplaning points
		Free_Assets = true,  -- Free asset purchases
		Free_Casino = true, -- Free casino purchases
		Free_Contracts = true, -- Free contract purchases
		Free_Masks = true, -- Free mask purchases
		Free_PrePlanning = true, -- Free preplanning purchases
		Free_Slots = true, -- Free weapon/mask slot purchases
		Free_Weapons = true, -- Free weapon purchases
		Free_Weapon_Mods = true, -- Free weapon mod purchases
	------------------------
	-- Bullet Penetration --
	------------------------
	Bullet_Penetration = true, -- Do you want enable bullet penetration?
		Bullet_Penetration_Enemy = true, -- Shoot through enemies
		Bullet_Penetration_Shield = true, -- Shoot through shields
		Bullet_Penetration_Wall = true, -- Shoot through walls
	-------------------------
	-- Cook meth functions --
	-------------------------
	Rats_Message = true, -- Display correct chemical in chat message
	-------------------
	-- Hud functions --
	-------------------
	Skipper = true, -- Do you want enable hud functions?
		Dropin_Pause_Remove = true, -- Remove Drop-In pause when players are joining
		Skip_End_Screen = true, -- Allows you to skip end screen
		Skip_Press = false, -- Skip Press Enter to skip
		Auto_Pick_Card = false, -- Auto Select Random Card In Loot Drop Screen
	---------------------
	-- Toggle interact --
	---------------------
	Toggle_Interact = true, -- Interact toggle
	----------
	-- Rest --
	----------
	mod_list_lite = true, -- Corrects a problem with freezing game when you viewing list of BLT mods
	P3DHack_text = true, -- P3DHack text in main menu
	hints_1 = true, -- Show P3DHack text in loading page
	------------------------------
	-- Keybind options (On/Off) --
	------------------------------
	----------------
	-- AIM (Home) --
	----------------
	AIM = true, -- ONLY Premium
	------------------
	-- NoClip (End) --
	------------------
	NoClip = true, -- ONLY Premium
	---------------------------
	-- High Jump (Num Enter) --
	---------------------------
	Jumper = true, -- ONLY Premium
	-----------------------------------
	-- Ammo and health replenish (Z) --
	-----------------------------------
	Full_Replenish = true, -- Ammo and health replenish
	---------------
	-- X-Ray (X) --
	---------------
	X_Ray = true, -- Outline enemies, civilians and cams; Bound To 'X' in default
	------------------------
	-- Ammo replenish (C) --
	------------------------
	Ammo_Replenish = true, -- Ammo replenish
	----------------------
	-- Vehicle spawn (V)--
	----------------------
	Vehicle_Spawn = true, -- Spawn drivable vehicles on Cross-hair
	-----------------------
	-- GRENADE SPAWN (B) --
	-----------------------
	Grenade_Spawn = true, -- Spawn grenades
		Grenade_Spawn_Type = 'Random_Projectile', -- Select grenade type
		--[[
			"Random_Projectile",
			"frag",
			"launcher_frag",
			"launcher_frag_m32",
			"launcher_incendiary",
			"molotov",
			"rocket_frag",
			"wpn_prj_ace",
			"wpn_prj_four",
			"wpn_prj_hur",
			"wpn_prj_jav",
			"wpn_prj_target",
		]]
	----------------------------
	-- Spawn Gage package (\) --
	----------------------------
	Gage_Package = true, -- Spawn random Gage package on Cross-hair
	----------------------
	-- Locator (Insert) --
	----------------------
	Locator = true,
		showDistance = true, -- Shows the distance to the waypoint for each waypoint
		showGagePickups = true, -- Shows Gage pickups on the map
		showPlanks = true, -- Show planks on the map
		showSmallLoot = true, -- Shows grabbables, like loose money or jewelry
		showCrates = true, -- Shows openable crates, like the ones in Election Day
		showDoors = true, -- Shows a lock symbol on doors that require a keycard or ECM to open
		showCameraComputers = true, -- Shows where the computers to view cameras are on the map
		showDrills = true, -- Shows where you can place a small drill
		showThermite = true, -- Shows thermite pickup locations and where to use it
		showSewerManhole = true, -- Shows where sewer manhole covers are
		showHUDMessages = true, -- Displays various information on your HUD about the waypoints
		makeNoise = true, -- Makes a noise when the script is run
		iterativeToggle = true, -- On means that every time you run the script, it will find the next available waypoint to show. Off means it will show all waypoints at once
		sheaterNewb = true, -- Enabling this will show a lot of things to other people, like the goats and voting machines
	-------------------------
	-- Kill all (NUMPAD *) --
	-------------------------
	Ultimate_Kill = true, -- Kill all AI
		IgnoreCivilians = false, -- Do you want ignore civilians?
		IgnoreCameras = false, -- Do you want ignore cameras?
		IgnoreEnemies = false, -- Do you want ignore enemies?
		NoBagBodies = false, -- Do you want no bag bodies?
	--------------------------
	-- Slow Motion (Delete) --
	--------------------------
	SlowMotion = true,
	---------------------
	-- Revive Team (/) --
	---------------------
	Revive_Team = true,
	----------------------------
	-- Push Stack (Backspace) --
	----------------------------
	Push_Stack = true,
	-----------------------
	-- Push Stack Up (-) --
	-----------------------
	Push_Stack_Up = true,
	-------------------------
	-- Push Stack Down (=) --
	-------------------------
	Push_Stack_Down = true,
	------------------------
	-- Public XRay (Num-) --
	------------------------
	Public_XRay = true,
	-------------------------
	-- Pager Answer (Num.) --
	-------------------------
	Pager_Answer = true,
	----------------------------
	-- Restart job (NUMPAD /) --
	----------------------------
	Restart_Job = true, -- Restart job (Host Only)
	----------------------
	-- HUD toggle (F10) --
	----------------------
	Hud_Toggle = true, -- Toggle to hide/show InGame HUD
	------------------
	-- Grenade Buff --
	------------------
	-------------------
	-- Dynamite Buff --
	-------------------
	Dynamite_Buff = false, -- Dynamite buff
		Dynamite_Damage_Buff = 1000, -- Dynamite damage buff (Default 30)
		Dynamite_Self_Damage = 0, -- Dynamite self damage buff (Default 10)
		Dynamite_Range_Buff = 2000, -- Dynamite range buff (Default 1000)
	---------------
	-- GL40 Buff --
	---------------
	GL40_Buff = false, -- GL40 Launcher buff
		GL40_Buff_Damage_Amount = 2000, -- GL40 Launcher damage buff amount (Default 34)
		GL40_Buff_Player_Damage_Amount = 0, -- GL40 Launcher self damage buff amount (Default 8)
		GL40_Buff_Range_Amount = 2000, -- GL40 Launcher explosion range buff amount (Default 350)
		GL40_Buff_Time_Amount = 5, -- GL40 Launcher explosion timer before impact buff amount (Default 2.5)
	------------------
	-- Grenade Buff --
	------------------
	Grenade_Buff = false, -- Grenade buff
		Grenade_Buff_Damage_Amount = 300, -- Grenade damage buff amount (Default 30)
		Grenade_Buff_Player_Damage_Amount = 10, -- Grenade self damage amount (Default 10)
		Grenade_Buff_Range_Amount = 1200, -- Grenade damage buff range amount (Default 1000)
	-----------------------------
	-- Incendiary Grenade Buff --
	-----------------------------
	Incendiary_Grenade_Buff = false, -- Incendiary grenade buff
		Incendiary_Grenade_Buff_Damage_Amount = 2000, -- Incendiary grenade damage buff amount (Default 3)
		Incendiary_Grenade_Buff_Player_Damage_Amount = 0, -- Incendiary grenade self damage buff amount (Default 2)
		Incediary_Grenade_Buff_Range_Amount = 2000, -- Incendiary grenade range buff amount (Default 75)
		Incendiary_Grenade_Buff_Burn_Duration_Amount = 5, -- Incendiary grenade burn duration buff (Default 6)
		Incendiary_Grenade_Buff_Time_Amount = 2.5, -- Incendiary grenade explosion timer before impact buff amount (Default 2.5)
	------------------
	-- Molotov Buff --
	------------------
	Molotov_Buff = false, -- Molotov buff
		Molotov_Buff_Damage_Amount = 2000, -- Molotov damage buff amount (Default 3)
		Molotov_Buff_Player_Damage_Amount = 0, -- Molotov self damage buff amount (Default 2)
		Molotov_Buff_Range_Amount = 10000, -- Molotov range buff amount (Default 75)
		Molotov_Buff_Burn_Duration_Amount = 30, -- Molotov burn duration buff (Default 20)
	---------------
	-- RPG7 Buff --
	---------------
	RPG7_Buff = false, -- RPG-7 Buff
		RPG7_Buff_Damage_Amount = 2000, -- RPG-7 damage buff amount (Default 1000)
		RPG7_Buff_Player_Damage_Amount = 0, -- RPG-7 self damage buff amount (Default 40)
		RPG7_Buff_Range_Amount = 2000, -- RPG-7 explosion range buff amount (Default 500)
		RPG7_Buff_Time_Amount = 5, -- RPG-7 explosion timer before impact buff amount (Default 2.5)
	------------------
	-- RSS Settings --
	------------------
	removeNewHeistsGui = true, -- Remove main menu banner
	removeWallet = true, -- Remove offshore and coins amount from crime spree lobby
	OFFSET_X = 0, -- Specify horisontal offset of the news feed
	OFFSET_Y = 0, -- Specify vertical offset of the news feed
	PRESENT_TIME = 0.5, -- How long does it take each title to appear
	SUSTAIN_TIME = 6, -- How long each title stays on screen
	REMOVE_TIME = 0.5, -- How long does it take each title to disappear
	MAX_NEWS = 30, -- Max news to load from every source
	MAX_NEWS_SHOW = 4, -- MAX_NEWS_SHOW_desc":"Total amount of news to rotate. Each source gets equal amount
	MIX = false, -- Titles mixing. If OFF then titles will be shown in the order of the sources in the config
	show_spree = true, -- Show RSS in crime spree lobby
	show_main = true, -- Show RSS in main menu
	show_lobby = true, -- Show RSS in lobby
	show_pause = true, -- Show RSS in pause menu
	-----------------------
	-- Automatic enabled --
	-----------------------
	-----------------
	-- Auto cheats --
	-----------------
	Auto_Cheats = true, -- Auto on cheats
	----------------------
	--Dodge Chance Buff --
	----------------------
	Dodge_Chance_Buff = false, -- Dodge chance
	Dodge_Chance_Buff_Amount = 0.5, -- Dodge chance amount (0.1 = 10%, 1 = 100%)
	----------------
	-- Melee Buff --
	----------------
	Melee_Buff = false, -- Melee damage buff
	Melee_Buff_Amount = 1000, -- Melee damage buff multiplier amount
	------------------------
	-- Unlimited BodyBags --
	------------------------
	Unlimited_BodyBags = false, -- Unlimited BodyBags
	----------
	-- Mask --
	----------
	Jump_Mask_Off = true, -- Jump with mask off
	Fast_Mask = false, -- Fast mask
	-----------------------------
	-- Infinite Hostage Follow --
	-----------------------------
	Infinite_Hostage_Follow = false, -- Infinite amount of following hostages
	--------------------------
	-- Interaction CoolDown --
	--------------------------
	Interaction_CoolDown = false, -- No interaction cooldown
	-----------------------
	-- Sixth Sense Reset --
	-----------------------
	Sixth_Sense_Reset = false, -- 6th sense only resets when you moving
	------------------
	-- Bag CoolDown --
	------------------
	Bag_CoolDown = false, -- No bag CoolDown
	-------------------------------------
	-- Camera Bag Explosion Multiplier --
	-------------------------------------
	Camera_Bag_Explosion_Multiplier = false, -- Explosive bag camera effect multiplier
	Camera_Bag_Explosion_Multiplier_Amount = 0, -- Explosive bag camera effect multiplier (Default 4)
	--------------------
	-- Explosion Buff --
	--------------------
	Explosion_Buff = false, -- All explosions damage buff
	Explosion_Buff_Amount = 500, -- All explosions damage buff amount
	---------------------
	-- Lowered Headbob --
	---------------------
	Lowered_Headbob = false, -- Lowered Head-bob
	-----------------
	-- No job heat --
	-----------------
	No_Job_Heat = true, -- Disable repeated job penalties
	Job_Heat_Amount = 1.20, -- Set job heat bonus amount (Default 1.15 = 15%)
	-------------------
	-- XP Multiplier --
	-------------------
	XP_Multiplier = false, -- XP Multiplier
	XP_Multiplier_Amount = 2, -- XP Multiplier amount
	-------------------------------
	-- Secure body bags for cash --
	-------------------------------
	Secure_BodyBags = false, -- Secure body bags for cash (Host Only)
	Secure_BodyBags_Loot_Value = 1000, -- Secure body bags for cash value amount
	---------------------------
	-- Other pregame options --
	---------------------------
	Grenade_Restrict = false, -- Restrict grenades being thrown while in stealth
	Pager_Mod = false, -- Increase pager count on available maps (Host Only)
	------------------------
	-- Zipline carry drop --
	------------------------
	Zipline_Drop = true, -- Drop bags that you are carrying while on zip-line
	--------------------
	-- Open all doors --
	--------------------
	Classic_Open_Door = true, -- Classic option of open all doors may not work everywhere, but is more limited to specific doors
	New_Open_Door = true, -- New option of open all doors, opens all pick locakable doors, safes, deposit boxes and etc. Which classic option does not do
	------------------------
	-- Disable Anti-Cheat --
	------------------------
	Anti_Cheat_Disable = true, -- Disable Anti-Cheat
}